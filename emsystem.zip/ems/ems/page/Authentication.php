<?php

    include_once './ems/model/authenticationModel.php';
    include './ems/model/Connector.php';
    include './ems/model/server.php';

session_start();

// ================== Database Class ==================
class Database
{
    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $dbname = "ems_db";
    public $conn;

    public function __construct()
    {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
}

// ================== School Data Class ==================
class SchoolManager
{
    private $db;

    public function __construct($dbConn)
    {
        $this->db = $dbConn;
    }

    public function getStats()
    {
        $result = $this->db->query("SELECT * FROM users");

        if ($result) {
            return $result->fetch_all(MYSQLI_ASSOC);
        }

        return [];
    }

    public function getUsers()
    {
        $result = $this->db->query("SELECT * FROM users");

        if ($result) {
            return $result->fetch_all(MYSQLI_ASSOC);
        }

        return [];
    }
}

// ================== Initialization ==================
$db = new Database();
$school = new SchoolManager($db->conn);

// Corrected line
$users = $school->getUsers();

// Include the view file (the HTML)
include './ems/views/auth.php';