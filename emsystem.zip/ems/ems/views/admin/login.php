<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE user_name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // If passwords are NOT hashed
        if ($password == $row['user_pass']) {

            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['user_role'] = $row['user_role'];

            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NextKit | Login</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;

            /* School Background Image with Dark Overlay */
            background:
                linear-gradient(rgba(0, 0, 0, 0.55), rgba(0, 0, 0, 0.55)),
                url('https://scontent.fceb6-3.fna.fbcdn.net/v/t39.30808-6/536267980_3126241167528663_179359250517254412_n.jpg?stp=cp6_dst-jpg_tt6&_nc_cat=101&ccb=1-7&_nc_sid=2a1932&_nc_ohc=Jt0Ctp6tk4sQ7kNvwHHaIwj&_nc_oc=AdmWFb4yioo2BOb5taJjuDJKJMdoIVr4NM_58y7EAGtOXKUEh-P8af86YprtdftnggQ&_nc_zt=23&_nc_ht=scontent.fceb6-3.fna&_nc_gid=1D1O3mUMil_sKMssdpqogQ&oh=00_AfvDlAbi17Ig3bmGAM8D4_6Zdsm-0-kuT80plbGtG-NCPA&oe=69A583A1');

            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.25);
        }

        .logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 25px;
        }

        .logo-img {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 12px;
            margin-bottom: 10px;
        }

        .logo h2 {
            font-size: 22px;
            font-weight: 600;
            color: #111827;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #374151;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.3s ease;
            background: white;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .remember {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            margin-bottom: 20px;
            color: #374151;
        }

        .remember input {
            accent-color: #2563eb;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: white;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-btn:hover {
            opacity: 0.9;
        }

        .register {
            margin-top: 25px;
            padding-top: 18px;
            border-top: 1px solid #e5e7eb;
            text-align: center;
            font-size: 14px;
            color: #6b7280;
        }

        .register a {
            color: #2563eb;
            font-weight: 600;
            text-decoration: none;
        }

        .register a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <div class="login-card">

        <div class="logo">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWzjUEQ1sCA6A1bnpVoojVV7zNi7vdyYpXfA&s"
                alt="Logo"
                class="logo-img">
            <h2>Login</h2>
        </div>

        <form action="./includes/sidebar.php" method="POST">

            <!-- User Role -->
            <div class="form-group">
                <label for="role">User Role</label>
                <select name="role" id="role" required>
                    <option value="" disabled selected>Select Role</option>
                    <option value="admin">Administrator</option>
                    <option value="registrar">Registrar</option>
                    <option value="faculty">Faculty</option>
                    <option value="staff">Staff</option>
                    <option value="guard">Guard</option>
                </select>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="admin@gmail.com" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>

            <div class="remember">
                <input type="checkbox" id="remember">
                <label for="remember">Remember this Device</label>
            </div>

            <button type="submit" class="login-btn">Sign in</button>

        </form>

        <div class="register">
            New here? <a href="./register.php">Create an account</a>
        </div>

    </div>

</body>

</html>