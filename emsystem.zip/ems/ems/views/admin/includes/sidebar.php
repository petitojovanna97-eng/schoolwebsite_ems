<?php
// session_start();
// You can check if user role is admin here
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | Enrollment System</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            background: #f3f4f6;
        }

        /* SIDEBAR */
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #111827;
            color: white;
            padding: 20px;
            position: fixed;
        }

        .sidebar h2 {
            font-size: 20px;
            margin-bottom: 30px;
            text-align: center;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 15px;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #d1d5db;
            display: block;
            padding: 10px 15px;
            border-radius: 8px;
            transition: 0.3s;
            font-size: 14px;
        }

        .sidebar ul li a:hover {
            background: #2563eb;
            color: white;
        }

        /* MAIN CONTENT */
        .main {
            margin-left: 250px;
            width: 100%;
        }

        /* TOPBAR */
        .topbar {
            background: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .topbar h3 {
            font-weight: 600;
            color: #111827;
        }

        .logout-btn {
            background: #ef4444;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 6px;
            cursor: pointer;
        }

        .logout-btn:hover {
            opacity: 0.9;
        }

        /* DASHBOARD CONTENT */
        .content {
            padding: 25px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }

        .card h4 {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h2>EMS Admin</h2>
        <ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Manage Students</a></li>
            <li><a href="#">Manage Faculty</a></li>
            <li><a href="#">Enrollment Requests</a></li>
            <li><a href="#">Courses & Subjects</a></li>
            <li><a href="#">Reports</a></li>
            <li><a href="#">System Settings</a></li>
        </ul>
    </div>

    <!-- MAIN -->
    <div class="main">

        <!-- TOPBAR -->
        <div class="topbar">
            <h3>Administrator Panel</h3>
            <button class="logout-btn">Logout</button>
        </div>

        <!-- CONTENT -->
        <div class="content">

            <div class="card">
                <h4>Welcome, Admin</h4>
                <p>This is your Enrollment Management System dashboard.</p>
            </div>

            <div class="card">
                <h4>System Overview</h4>
                <p>Total Students: 0</p>
                <p>Total Faculty: 0</p>
                <p>Pending Enrollments: 0</p>
            </div>

        </div>

    </div>

</body>

</html>