<?php
// ================= DATABASE CONNECTION =================
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ems_db";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ================= FETCH DASHBOARD STATS =================
$total_students = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'] ?? 0;
$total_enrolled = $conn->query("SELECT COUNT(*) as total FROM enrollment_info WHERE status = 'Active'")->fetch_assoc()['total'] ?? 0;
$total_pending  = $conn->query("SELECT COUNT(*) as total FROM enrollment_info WHERE status = 'Pending'")->fetch_assoc()['total'] ?? 0;

$max_slots = 600;
$available_slots = max(0, $max_slots - ($total_enrolled + $total_pending));

$recent_students = $conn->query("SELECT * FROM students ORDER BY stud_id DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMS | Admin Dashboard</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --secondary: #64748b;
            --bg-main: #f8fafc;
            --sidebar-bg: #0f172a;
            --glass-white: rgba(255, 255, 255, 0.9);
            --card-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--bg-main);
            color: #1e293b;
            overflow-x: hidden;
        }

        /* Layout Structure */
        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: #fff;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            position: sticky;
            top: 0;
            height: 100vh;
            z-index: 1000;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 1rem 0.5rem 2.5rem;
        }

        .brand-logo {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 10px;
            display: grid;
            place-items: center;
            font-weight: bold;
        }

        .nav-group {
            margin-bottom: 1.5rem;
        }

        .nav-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            margin-bottom: 0.75rem;
            padding-left: 0.75rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.8rem 1rem;
            color: #94a3b8;
            text-decoration: none;
            border-radius: 12px;
            margin-bottom: 4px;
            transition: var(--transition);
            font-size: 0.9rem;
            cursor: pointer;
        }

        .nav-link i {
            width: 24px;
            font-size: 1.1rem;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
        }

        .nav-link.active {
            background: var(--primary);
            color: #fff;
        }

        .submenu {
            margin-left: 2.2rem;
            border-left: 1px solid rgba(255, 255, 255, 0.1);
            display: none;
        }

        .submenu.open {
            display: block;
        }

        .submenu a {
            display: block;
            padding: 0.6rem 1rem;
            color: #94a3b8;
            text-decoration: none;
            font-size: 0.85rem;
            transition: var(--transition);
        }

        .submenu a:hover {
            color: #fff;
        }

        /* --- MAIN CONTENT --- */
        .main-content {
            flex: 1;
            padding: 2rem;
        }

        /* Top Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .search-wrapper {
            position: relative;
            width: 350px;
        }

        .search-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .search-wrapper input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            background: #fff;
            outline: none;
            transition: var(--transition);
        }

        .search-wrapper input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2.5rem;
        }

        .stat-card {
            background: #fff;
            padding: 1.5rem;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            border: 1px solid #f1f5f9;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card .icon-box {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            margin-bottom: 1rem;
        }

        .stat-card h3 {
            font-size: 0.9rem;
            color: var(--secondary);
            font-weight: 500;
        }

        .stat-card .value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-top: 0.2rem;
        }

        /* Section Styling */
        .content-card {
            background: #fff;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--card-shadow);
            margin-bottom: 2rem;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 1rem;
            color: var(--secondary);
            font-size: 0.85rem;
            border-bottom: 2px solid #f1f5f9;
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.9rem;
        }

        .status-pill {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-pill.active {
            background: #dcfce7;
            color: #166534;
        }

        .status-pill.pending {
            background: #fef3c7;
            color: #92400e;
        }

        .btn-view {
            padding: 6px 16px;
            background: #f1f5f9;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            color: var(--primary);
            transition: var(--transition);
        }

        .btn-view:hover {
            background: var(--primary);
            color: #fff;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
                padding: 1rem 0.5rem;
            }

            .sidebar .nav-label,
            .sidebar span,
            .brand h2,
            .sidebar .submenu {
                display: none;
            }

            .nav-link {
                justify-content: center;
            }
        }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f8fafc;
        }

        .app-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #0f172a;
            color: #fff;
            padding: 20px;
        }

        .sidebar a {
            display: block;
            padding: 10px;
            color: #94a3b8;
            text-decoration: none;
            border-radius: 8px;
        }

        .sidebar a:hover {
            background: #1e293b;
            color: #fff;
        }

        .main-content {
            flex: 1;
            padding: 30px;
        }

        .stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .stat-card h3 {
            margin: 0;
            font-size: 14px;
            color: #64748b;
        }

        .stat-card .value {
            font-size: 28px;
            font-weight: 700;
            margin-top: 10px;
        }

        .content-card {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .btn-primary {
            background: #4f46e5;
            color: #fff;
        }

        .btn-secondary {
            background: #e2e8f0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        input,
        select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .section-title {
            margin: 25px 0 10px;
            font-weight: 600;
        }
    </style>
</head>

<body>
    <div class="app-container">
        <aside class="sidebar">
            <div class="brand">
                <div class="brand-logo"><i class="fas fa-graduation-cap"></i></div>
                <h2>EMS</h2>
            </div>

            <div class="nav-group">
                <p class="nav-label">Main Menu</p>
                <a href="../dashboard.php" class="nav-link">
                    <i class="fas fa-columns"></i> <span>Dashboard</span>
                </a>

                <div class="nav-link active" onclick="toggleSub(this)">
                    <i class="fas fa-user-graduate"></i> <span>Students</span>
                    <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.7rem;"></i>
                </div>
                <div class="submenu">
                    <a href="../stud_management/add_student.php">Add New</a>
                    <a href="../stud_management/stud_list.php">Directory</a>
                    <a href="../stud_management/attendance.php">Attendance</a>
                </div>

                <div class="nav-link" onclick="toggleSub(this)">
                    <i class="fas fa-file-signature"></i> <span>Enrollment</span>
                    <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.7rem;"></i>
                </div>
                <div class="submenu">
                    <a href="#">Applications</a>
                    <a href="#">Approvals</a>
                </div>
            </div>

            <div class="nav-group">
                <p class="nav-label">Academic</p>
                <a href="#" class="nav-link"><i class="fas fa-book"></i> <span>Curriculum</span></a>
                <a href="#" class="nav-link"><i class="fas fa-calendar-alt"></i> <span>Schedules</span></a>
                <a href="#" class="nav-link"><i class="fas fa-chart-pie"></i> <span>Reports</span></a>
            </div>

            <div class="nav-group" style="margin-top: auto;">
                <a href="../../index.php" class="nav-link" style="color: #f87171;">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </aside>
        <!-- ================= MAIN CONTENT ================= -->
        <div class="main-content">

            <h1>Dashboard Overview</h1>

            <div class="stat-grid">
                <div class="stat-card">
                    <h3>Total Students</h3>
                    <div class="value"><?= number_format($total_students) ?></div>
                </div>
                <div class="stat-card">
                    <h3>Fully Enrolled</h3>
                    <div class="value"><?= number_format($total_enrolled) ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending</h3>
                    <div class="value"><?= number_format($total_pending) ?></div>
                </div>
                <div class="stat-card">
                    <h3>Available Slots</h3>
                    <div class="value"><?= number_format($available_slots) ?></div>
                </div>
            </div>

            <!-- ================= RECENT REGISTRATIONS ================= -->
            <div class="content-card">
                <h3>Recent Registrations</h3>

                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recent_students->num_rows > 0): ?>
                            <?php while ($row = $recent_students->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['firstname'] . " " . $row['lastname']) ?></td>
                                    <td><button class="btn btn-secondary">View</button></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">No records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- ================= ADD STUDENT FORM ================= -->
            <div class="content-card" style="margin-top:30px;">
                <h2>Add Student</h2>

                <form action="process_student.php" method="POST">

                    <div class="section-title">Personal Information</div>
                    <div class="form-grid">
                        <input type="text" name="stud_LRN" placeholder="LRN" required>
                        <input type="text" name="stud_first_name" placeholder="First Name" required>
                        <input type="text" name="stud_last_name" placeholder="Last Name" required>
                        <select name="stud_sex" required>
                            <option value="">Sex</option>
                            <option>Male</option>
                            <option>Female</option>
                        </select>
                        <input type="date" name="stud_date_of_birth" required>
                    </div>

                    <div class="section-title">Academic Information</div>
                    <div class="form-grid">
                        <select name="grade_level" required>
                            <option value="">Grade Level</option>
                            <option>Grade 7</option>
                            <option>Grade 8</option>
                            <option>Grade 9</option>
                            <option>Grade 10</option>
                            <option>Grade 11</option>
                            <option>Grade 12</option>
                        </select>
                        <input type="text" name="section" placeholder="Section" required>
                        <input type="text" name="school_year_to_enroll" placeholder="2025-2026" required>
                    </div>

                    <div style="margin-top:20px;">
                        <button type="reset" class="btn btn-secondary">Clear</button>
                        <button type="submit" class="btn btn-primary">Enroll Student</button>
                    </div>

                </form>
            </div>

        </div>
    </div>
</body>

</html>