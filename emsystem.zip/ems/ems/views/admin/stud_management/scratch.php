<?php
// Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ems_db";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Data Fetching
$total_students = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'] ?? 0;
$total_enrolled = $conn->query("SELECT COUNT(*) as total FROM enrollment_info WHERE status = 'Active'")->fetch_assoc()['total'] ?? 0;
$total_pending  = $conn->query("SELECT COUNT(*) as total FROM enrollment_info WHERE status = 'Pending'")->fetch_assoc()['total'] ?? 0;

$max_slots = 600;
$available_slots = max(0, $max_slots - ($total_enrolled + $total_pending));
?>

<?php
include "../../nav/server_sidebar.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMS | Pro Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../style/admin_dashboard.css">

    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --secondary: #64748b;
            --bg-main: #f8fafc;
            --sidebar-bg: #0f172a;
            --glass-white: rgba(255, 255, 255, 0.9);
            --card-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background-color: var(--bg-main);
            color: #1e293b;
            overflow-x: hidden;
        }

        /* Layout Structure */
        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: #fff;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            position: sticky;
            top: 0;
            height: 100vh;
            z-index: 1000;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 1rem 0.5rem 2.5rem;
        }

        .brand-logo {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 10px;
            display: grid;
            place-items: center;
            font-weight: bold;
        }

        .nav-group {
            margin-bottom: 1.5rem;
        }

        .nav-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            margin-bottom: 0.75rem;
            padding-left: 0.75rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 0.8rem 1rem;
            color: #94a3b8;
            text-decoration: none;
            border-radius: 12px;
            margin-bottom: 4px;
            transition: var(--transition);
            font-size: 0.9rem;
            cursor: pointer;
        }

        .nav-link i {
            width: 24px;
            font-size: 1.1rem;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
        }

        .nav-link.active {
            background: var(--primary);
            color: #fff;
        }

        .submenu {
            margin-left: 2.2rem;
            border-left: 1px solid rgba(255, 255, 255, 0.1);
            display: none;
        }

        .submenu.open {
            display: block;
        }

        .submenu a {
            display: block;
            padding: 0.6rem 1rem;
            color: #94a3b8;
            text-decoration: none;
            font-size: 0.85rem;
            transition: var(--transition);
        }

        .submenu a:hover {
            color: #fff;
        }

        /* --- MAIN CONTENT --- */
        .main-content {
            flex: 1;
            padding: 2rem;
        }

        /* Top Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .search-wrapper {
            position: relative;
            width: 350px;
        }

        .search-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .search-wrapper input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            background: #fff;
            outline: none;
            transition: var(--transition);
        }

        .search-wrapper input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2.5rem;
        }

        .stat-card {
            background: #fff;
            padding: 1.5rem;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            border: 1px solid #f1f5f9;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card .icon-box {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            margin-bottom: 1rem;
        }

        .stat-card h3 {
            font-size: 0.9rem;
            color: var(--secondary);
            font-weight: 500;
        }

        .stat-card .value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-top: 0.2rem;
        }

        /* Section Styling */
        .content-card {
            background: #fff;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--card-shadow);
            margin-bottom: 2rem;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 1rem;
            color: var(--secondary);
            font-size: 0.85rem;
            border-bottom: 2px solid #f1f5f9;
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid #f1f5f9;
            font-size: 0.9rem;
        }

        .status-pill {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .status-pill.active {
            background: #dcfce7;
            color: #166534;
        }

        .status-pill.pending {
            background: #fef3c7;
            color: #92400e;
        }

        .btn-view {
            padding: 6px 16px;
            background: #f1f5f9;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            color: var(--primary);
            transition: var(--transition);
        }

        .btn-view:hover {
            background: var(--primary);
            color: #fff;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 80px;
                padding: 1rem 0.5rem;
            }

            .sidebar .nav-label,
            .sidebar span,
            .brand h2,
            .sidebar .submenu {
                display: none;
            }

            .nav-link {
                justify-content: center;
            }
        }

        :root {
            --primary: #1d4ed8;
            --primary-hover: #1e3a8a;
            --primary-light: #e0e7ff;
            --dark: #0f172a;
            --bg: #f1f5f9;
            --card: #ffffff;
            --text: #1e293b;
            --muted: #64748b;
            --border: #e2e8f0;
            --success: #16a34a;
            --warning: #f59e0b;
            --danger: #dc2626;
            --transition: .3s;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
        }

        /* Layout */
        .wrapper {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--dark);
            color: #fff;
            padding: 20px;
            display: flex;
            flex-direction: column;
            position: sticky;
            top: 0;
            height: 100vh;
        }

        .sidebar h2 {
            font-size: 20px;
            margin-bottom: 30px;
            color: var(--primary-light);
            text-align: center;
            letter-spacing: 1px;
        }

        .menu {
            flex: 1;
        }

        .menu-item {
            padding: 12px 15px;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 5px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: var(--transition);
        }

        .menu-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .menu-item.active {
            background: var(--primary);
        }

        .submenu {
            display: none;
            padding-left: 20px;
            margin-bottom: 10px;
        }

        .submenu div {
            padding: 8px 12px;
            font-size: 13px;
            color: #cbd5e1;
            cursor: pointer;
            border-radius: 6px;
            transition: var(--transition);
        }

        .submenu div:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
        }

        .logout {
            margin-top: auto;
            padding: 12px;
            background: rgba(220, 38, 38, 0.2);
            color: #fca5a5;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }

        .logout:hover {
            background: var(--danger);
            color: white;
        }

        /* Main Content */
        .main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        /* Topbar */
        .topbar {
            background: var(--card);
            padding: 15px 25px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .search-box input {
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 8px;
            width: 300px;
            outline: none;
        }

        .top-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .notification,
        .profile {
            cursor: pointer;
            position: relative;
            font-size: 14px;
            font-weight: 500;
        }

        /* Form Styling */
        .content {
            padding: 30px;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        .form-card {
            background: var(--card);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        .section-title {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary);
            margin: 25px 0 15px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title::after {
            content: "";
            flex: 1;
            height: 1px;
            background: var(--border);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: var(--muted);
        }

        .form-input {
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .form-input:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px var(--primary-light);
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .form-actions {
            margin-top: 40px;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
        }

        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: var(--transition);
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-hover);
        }

        .btn-secondary {
            background: var(--bg);
            color: var(--text);
        }

        @media (max-width: 768px) {
            .wrapper {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .search-box input {
                width: 150px;
            }
        }
    </style>



</head>

<body>

    <div class="app-container">

        <main class="main-content">
            <header>
                <div class="search-wrapper">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Quick search students or records...">
                </div>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <div style="position: relative; cursor: pointer;">
                        <i class="far fa-bell" style="font-size: 1.2rem; color: var(--secondary);"></i>
                        <span style="position: absolute; top: -5px; right: -5px; background: var(--primary); width: 8px; height: 8px; border-radius: 50%;"></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="text-align: right;">
                            <p style="font-weight: 700; font-size: 0.85rem;">Admin User</p>
                            <p style="font-size: 0.75rem; color: var(--secondary);">Super Admin</p>
                        </div>
                        <img src="https://ui-avatars.com/api/?name=Admin+User&background=4f46e5&color=fff" style="width: 40px; border-radius: 10px;">
                    </div>
                </div>
            </header>

            <h1 style="margin-bottom: 1.5rem; font-weight: 800; letter-spacing: -0.02em;">Overview</h1>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon-box" style="background: rgba(79, 70, 229, 0.1); color: var(--primary);">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Total Population</h3>
                    <div class="value"><?= number_format($total_students) ?></div>
                </div>
                <div class="stat-card">
                    <div class="icon-box" style="background: rgba(22, 163, 74, 0.1); color: #16a34a;">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h3>Fully Enrolled</h3>
                    <div class="value"><?= number_format($total_enrolled) ?></div>
                </div>
                <div class="stat-card">
                    <div class="icon-box" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h3>Pending Review</h3>
                    <div class="value"><?= number_format($total_pending) ?></div>
                </div>
                <div class="stat-card">
                    <div class="icon-box" style="background: rgba(220, 38, 38, 0.1); color: #dc2626;">
                        <i class="fas fa-door-open"></i>
                    </div>
                    <h3>Available Slots</h3>
                    <div class="value"><?= number_format($available_slots) ?></div>
                </div>
            </div>

            <main class="content">
                <div class="form-card">
                    <header style="margin-bottom: 20px;">
                        <h1 style="font-size: 22px;">Student Enrollment Form</h1>
                        <p style="color: var(--muted); font-size: 14px;">Complete the fields below to register a new student.</p>
                    </header>

                    <form action="process_student.php" method="POST">

                        <!-- ================= PERSONAL INFORMATION ================= -->
                        <div class="section-title">Personal Information</div>
                        <div class="form-grid">

                            <div class="form-group">
                                <label>LRN *</label>
                                <input type="text" name="stud_LRN" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>First Name *</label>
                                <input type="text" name="stud_first_name" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Middle Name</label>
                                <input type="text" name="stud_middle_name" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Last Name *</label>
                                <input type="text" name="stud_last_name" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Extension Name</label>
                                <input type="text" name="stud_ext_name" class="form-input" placeholder="Jr., Sr., III">
                            </div>

                            <div class="form-group">
                                <label>Sex *</label>
                                <select name="stud_sex" required class="form-input">
                                    <option value="">Select</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Date of Birth *</label>
                                <input type="date" name="stud_date_of_birth" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Place of Birth</label>
                                <input type="text" name="stud_place_of_birth" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Religion</label>
                                <input type="text" name="stud_religion" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Mother Tongue</label>
                                <input type="text" name="stud_mother_tongue" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Nationality</label>
                                <input type="text" name="stud_nationality" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Indigenous Group</label>
                                <input type="text" name="stud_indigenous_group" class="form-input">
                            </div>

                        </div>

                        <!-- ================= ADDRESS ================= -->
                        <div class="section-title">Home Address</div>
                        <div class="form-grid">

                            <div class="form-group">
                                <label>House No.</label>
                                <input type="text" name="house_no" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Street</label>
                                <input type="text" name="street" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Barangay</label>
                                <input type="text" name="brgy" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Municipality</label>
                                <input type="text" name="municipality" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Province</label>
                                <input type="text" name="province" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>ZIP Code</label>
                                <input type="text" name="zip_code" class="form-input">
                            </div>

                        </div>

                        <!-- ================= GUARDIAN ================= -->
                        <div class="section-title">Parent / Guardian Information</div>
                        <div class="form-grid">

                            <div class="form-group">
                                <label>Relationship *</label>
                                <select name="relationship" required class="form-input">
                                    <option value="">Select</option>
                                    <option>Father</option>
                                    <option>Mother</option>
                                    <option>Guardian</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>First Name *</label>
                                <input type="text" name="guardian_first_name" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Middle Name</label>
                                <input type="text" name="guardian_middle_name" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Last Name *</label>
                                <input type="text" name="guardian_last_name" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Occupation</label>
                                <input type="text" name="guardian_occupation" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Contact Number *</label>
                                <input type="text" name="guardian_contact_no" required class="form-input">
                            </div>

                        </div>

                        <!-- ================= ACADEMIC ================= -->
                        <div class="section-title">Academic Information</div>
                        <div class="form-grid">

                            <div class="form-group">
                                <label>Grade Level *</label>
                                <select name="grade_level" required class="form-input">
                                    <option value="">Select Grade</option>
                                    <option>Grade 7</option>
                                    <option>Grade 8</option>
                                    <option>Grade 9</option>
                                    <option>Grade 10</option>
                                    <option>Grade 11</option>
                                    <option>Grade 12</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Section *</label>
                                <input type="text" name="section" required class="form-input">
                            </div>

                            <div class="form-group">
                                <label>School Year *</label>
                                <input type="text" name="school_year_to_enroll" required class="form-input" placeholder="2025-2026">
                            </div>

                            <div class="form-group">
                                <label>Preferred Modality</label>
                                <input type="text" name="preferred_modality" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Semester</label>
                                <select name="semester" class="form-input">
                                    <option>1st Semester</option>
                                    <option>2nd Semester</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Track</label>
                                <input type="text" name="track" class="form-input">
                            </div>

                            <div class="form-group">
                                <label>Strand</label>
                                <input type="text" name="strand" class="form-input">
                            </div>

                        </div>

                        <div class="form-actions">
                            <button type="reset" class="btn btn-secondary">Clear Form</button>
                            <button type="submit" class="btn btn-primary">Enroll Student</button>
                        </div>

                    </form>
                </div>
            </main>
    </div>
    </div>

    <script>
        function toggleMenu(id) {
            const sub = document.getElementById(id);
            sub.style.display = sub.style.display === "block" ? "none" : "block";
        }

        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "logout.php";
            }
        }

        function toggleSub(el) {
            const submenu = el.nextElementSibling;
            const icon = el.querySelector('.fa-chevron-down');

            submenu.classList.toggle('open');
            icon.style.transform = submenu.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0deg)';
        }
    </script>

</body>

</html>