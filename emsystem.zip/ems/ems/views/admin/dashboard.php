<?php
// Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ems_db";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Data Fetching
$total_students = $conn->query("SELECT COUNT(*) as total FROM students")->fetch_assoc()['total'] ?? 0;
$total_enrolled = $conn->query("SELECT COUNT(*) as total FROM enrollment_info WHERE status = 'Active'")->fetch_assoc()['total'] ?? 0;
$total_pending  = $conn->query("SELECT COUNT(*) as total FROM enrollment_info WHERE status = 'Pending'")->fetch_assoc()['total'] ?? 0;

$max_slots = 600;
$available_slots = max(0, $max_slots - ($total_enrolled + $total_pending));

// ================= FETCH RECENT REGISTRATIONS =================
$recent_students = $conn->query("
    SELECT 
        s.stud_id,
        s.stud_first_name,
        s.stud_last_name,
        e.grade_level_to_enroll,
        e.status
    FROM students s
    LEFT JOIN enrollment_info e ON s.stud_id = e.stud_id
    ORDER BY s.stud_id DESC
    LIMIT 5
");

if (!$recent_students) {
  die("Query Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EMS | Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- <link rel="stylesheet" href="./../style/admin_dashboard.css"> -->

</head>

<style>
  :root {
    --primary: #4f46e5;
    --primary-hover: #4338ca;
    --secondary: #64748b;
    --bg-main: #f8fafc;
    --sidebar-bg: #0f172a;
    --glass-white: rgba(255, 255, 255, 0.9);
    --card-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Plus Jakarta Sans', sans-serif;
  }

  body {
    background-color: var(--bg-main);
    color: #1e293b;
    overflow-x: hidden;
  }

  /* Layout Structure */
  .app-container {
    display: flex;
    min-height: 100vh;
  }

  /* --- SIDEBAR --- */
  .sidebar {
    width: 280px;
    background: var(--sidebar-bg);
    color: #fff;
    padding: 1.5rem;
    display: flex;
    flex-direction: column;
    position: sticky;
    top: 0;
    height: 100vh;
    z-index: 1000;
  }

  .brand {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 1rem 0.5rem 2.5rem;
  }

  .brand-logo {
    width: 40px;
    height: 40px;
    background: var(--primary);
    border-radius: 10px;
    display: grid;
    place-items: center;
    font-weight: bold;
  }

  .nav-group {
    margin-bottom: 1.5rem;
  }

  .nav-label {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #64748b;
    margin-bottom: 0.75rem;
    padding-left: 0.75rem;
  }

  .nav-link {
    display: flex;
    align-items: center;
    padding: 0.8rem 1rem;
    color: #94a3b8;
    text-decoration: none;
    border-radius: 12px;
    margin-bottom: 4px;
    transition: var(--transition);
    font-size: 0.9rem;
    cursor: pointer;
  }

  .nav-link i {
    width: 24px;
    font-size: 1.1rem;
  }

  .nav-link:hover,
  .nav-link.active {
    background: rgba(255, 255, 255, 0.05);
    color: #fff;
  }

  .nav-link.active {
    background: var(--primary);
    color: #fff;
  }

  .submenu {
    margin-left: 2.2rem;
    border-left: 1px solid rgba(255, 255, 255, 0.1);
    display: none;
  }

  .submenu.open {
    display: block;
  }

  .submenu a {
    display: block;
    padding: 0.6rem 1rem;
    color: #94a3b8;
    text-decoration: none;
    font-size: 0.85rem;
    transition: var(--transition);
  }

  .submenu a:hover {
    color: #fff;
  }

  /* --- MAIN CONTENT --- */
  .main-content {
    flex: 1;
    padding: 2rem;
  }

  /* Top Header */
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
  }

  .search-wrapper {
    position: relative;
    width: 350px;
  }

  .search-wrapper i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--secondary);
  }

  .search-wrapper input {
    width: 100%;
    padding: 12px 15px 12px 45px;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    background: #fff;
    outline: none;
    transition: var(--transition);
  }

  .search-wrapper input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
  }

  /* Stats Grid */
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2.5rem;
  }

  .stat-card {
    background: #fff;
    padding: 1.5rem;
    border-radius: 20px;
    box-shadow: var(--card-shadow);
    border: 1px solid #f1f5f9;
    transition: var(--transition);
  }

  .stat-card:hover {
    transform: translateY(-5px);
  }

  .stat-card .icon-box {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: grid;
    place-items: center;
    margin-bottom: 1rem;
  }

  .stat-card h3 {
    font-size: 0.9rem;
    color: var(--secondary);
    font-weight: 500;
  }

  .stat-card .value {
    font-size: 1.8rem;
    font-weight: 700;
    margin-top: 0.2rem;
  }

  /* Section Styling */
  .content-card {
    background: #fff;
    border-radius: 20px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 2rem;
  }

  .table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
  }

  th {
    text-align: left;
    padding: 1rem;
    color: var(--secondary);
    font-size: 0.85rem;
    border-bottom: 2px solid #f1f5f9;
  }

  td {
    padding: 1rem;
    border-bottom: 1px solid #f1f5f9;
    font-size: 0.9rem;
  }

  .status-pill {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
  }

  .status-pill.active {
    background: #dcfce7;
    color: #166534;
  }

  .status-pill.pending {
    background: #fef3c7;
    color: #92400e;
  }

  .btn-view {
    padding: 6px 16px;
    background: #f1f5f9;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    color: var(--primary);
    transition: var(--transition);
  }

  .btn-view:hover {
    background: var(--primary);
    color: #fff;
  }

  @media (max-width: 1024px) {
    .sidebar {
      width: 80px;
      padding: 1rem 0.5rem;
    }

    .sidebar .nav-label,
    .sidebar span,
    .brand h2,
    .sidebar .submenu {
      display: none;
    }

    .nav-link {
      justify-content: center;
    }
  }
</style>

<body>

  <div class="app-container">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-logo"><i class="fas fa-graduation-cap"></i></div>
        <h2>EMS</h2>
      </div>

      <div class="nav-group">
        <p class="nav-label">Main Menu</p>
        <a href="./dashboard.php" class="nav-link active">
          <i class="fas fa-columns"></i> <span>Dashboard</span>
        </a>

        <div class="nav-link" onclick="toggleSub(this)">
          <i class="fas fa-user-graduate"></i> <span>Students</span>
          <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.7rem;"></i>
        </div>
        <div class="submenu">
          <a href="stud_management/add_student.php">Add New</a>
          <a href="stud_management/stud_list.php">Directory</a>
          <a href="stud_management/attendance.php">Attendance</a>
        </div>

        <div class="nav-link" onclick="toggleSub(this)">
          <i class="fas fa-file-signature"></i> <span>Enrollment</span>
          <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.7rem;"></i>
        </div>
        <div class="submenu">
          <a href="#">Applications</a>
          <a href="#">Approvals</a>
        </div>
      </div>

      <div class="nav-group">
        <p class="nav-label">Academic</p>
        <a href="#" class="nav-link"><i class="fas fa-book"></i> <span>Curriculum</span></a>
        <a href="#" class="nav-link"><i class="fas fa-calendar-alt"></i> <span>Schedules</span></a>
        <a href="#" class="nav-link"><i class="fas fa-chart-pie"></i> <span>Reports</span></a>
      </div>

      <div class="nav-group" style="margin-top: auto;">
        <a href="../../index.php" class="nav-link" style="color: #f87171;">
          <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
      </div>
    </aside>

    <main class="main-content">
      <header>
        <div class="search-wrapper">
          <i class="fas fa-search"></i>
          <input type="text" placeholder="Quick search students or records...">
        </div>
        <div style="display: flex; gap: 20px; align-items: center;">
          <div style="position: relative; cursor: pointer;">
            <i class="far fa-bell" style="font-size: 1.2rem; color: var(--secondary);"></i>
            <span style="position: absolute; top: -5px; right: -5px; background: var(--primary); width: 8px; height: 8px; border-radius: 50%;"></span>
          </div>
          <div style="display: flex; align-items: center; gap: 10px;">
            <div style="text-align: right;">
              <p style="font-weight: 700; font-size: 0.85rem;">Admin User</p>
              <p style="font-size: 0.75rem; color: var(--secondary);">Super Admin</p>
            </div>
            <img src="https://ui-avatars.com/api/?name=Admin+User&background=4f46e5&color=fff" style="width: 40px; border-radius: 10px;">
          </div>
        </div>
      </header>

      <h1 style="margin-bottom: 1.5rem; font-weight: 800; letter-spacing: -0.02em;">Overview</h1>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="icon-box" style="background: rgba(79, 70, 229, 0.1); color: var(--primary);">
            <i class="fas fa-users"></i>
          </div>
          <h3>Total Population</h3>
          <div class="value"><?= number_format($total_students) ?></div>
        </div>
        <div class="stat-card">
          <div class="icon-box" style="background: rgba(22, 163, 74, 0.1); color: #16a34a;">
            <i class="fas fa-check-circle"></i>
          </div>
          <h3>Fully Enrolled</h3>
          <div class="value"><?= number_format($total_enrolled) ?></div>
        </div>
        <div class="stat-card">
          <div class="icon-box" style="background: rgba(245, 158, 11, 0.1); color: #f59e0b;">
            <i class="fas fa-clock"></i>
          </div>
          <h3>Pending Review</h3>
          <div class="value"><?= number_format($total_pending) ?></div>
        </div>
        <div class="stat-card">
          <div class="icon-box" style="background: rgba(220, 38, 38, 0.1); color: #dc2626;">
            <i class="fas fa-door-open"></i>
          </div>
          <h3>Available Slots</h3>
          <div class="value"><?= number_format($available_slots) ?></div>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
        <div class="content-card">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <h3>Recent Registrations</h3>
            <button class="btn-view" style="background: var(--primary); color: white;">
              Export PDF
            </button>
          </div>

          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Grade Level</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>

              <?php if ($recent_students && $recent_students->num_rows > 0): ?>

                <?php while ($row = $recent_students->fetch_assoc()): ?>
                  <tr>

                    <!-- NAME -->
                    <td>
                      <strong>
                        <?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?>
                      </strong>
                    </td>

                    <!-- GRADE -->
                    <td>
                      <?= htmlspecialchars($row['grade_level'] ?? 'N/A') ?>
                    </td>

                    <!-- STATUS -->
                    <td>
                      <?php
                      $status = $row['status'] ?? 'Pending';
                      $class = strtolower($status) === 'active' ? 'active' : 'pending';
                      ?>
                      <span class="status-pill <?= $class ?>">
                        <?= htmlspecialchars($status) ?>
                      </span>
                    </td>

                    <!-- ACTION -->
                    <td>
                      <button class="btn-view">
                        Details
                      </button>
                    </td>

                  </tr>
                <?php endwhile; ?>

              <?php else: ?>
                <tr>
                  <td colspan="4" style="text-align:center;">
                    No recent records found.
                  </td>
                </tr>
              <?php endif; ?>

            </tbody>
          </table>
        </div>
      </div>

      <div class="content-card">
        <h2 style="font-size: 1.1rem; margin-bottom: 1.5rem;">System Logs</h2>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
          <div style="display: flex; gap: 12px; font-size: 0.85rem;">
            <div style="min-width: 8px; height: 8px; border-radius: 50%; background: var(--primary); margin-top: 5px;"></div>
            <div>
              <p><strong>Science 101</strong> curriculum updated.</p>
              <span style="color: var(--secondary); font-size: 0.75rem;">2 mins ago</span>
            </div>
          </div>
          <div style="display: flex; gap: 12px; font-size: 0.85rem;">
            <div style="min-width: 8px; height: 8px; border-radius: 50%; background: #16a34a; margin-top: 5px;"></div>
            <div>
              <p>3 new students finalized enrollment.</p>
              <span style="color: var(--secondary); font-size: 0.75rem;">1 hour ago</span>
            </div>
          </div>
        </div>
      </div>
  </div>
  </main>
  </div>

  <script>
    function toggleSub(el) {
      const submenu = el.nextElementSibling;
      const icon = el.querySelector('.fa-chevron-down');

      submenu.classList.toggle('open');
      icon.style.transform = submenu.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0deg)';
    }
  </script>

</body>

</html>