<!-- Sidebar Component -->
<aside class="sidebar">
    <div class="brand">
        <div class="brand-logo"><i class="fas fa-graduation-cap"></i></div>
        <h2>EMS</h2>
    </div>

    <div class="nav-group">
        <p class="nav-label">Main Menu</p>
        <a href="dashboard.php" class="nav-link active">
            <i class="fas fa-columns"></i> <span>Dashboard</span>
        </a>

        <div class="nav-link" onclick="toggleSub(this)">
            <i class="fas fa-user-graduate"></i> <span>Students</span>
            <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.7rem;"></i>
        </div>
        <div class="submenu">
            <a href="stud_management/add_student.php">Add New</a>
            <a href="stud_management/stud_list.php">Directory</a>
            <a href="stud_management/attendance.php">Attendance</a>
        </div>

        <div class="nav-link" onclick="toggleSub(this)">
            <i class="fas fa-file-signature"></i> <span>Enrollment</span>
            <i class="fas fa-chevron-down" style="margin-left: auto; font-size: 0.7rem;"></i>
        </div>
        <div class="submenu">
            <a href="#">Applications</a>
            <a href="#">Approvals</a>
        </div>
    </div>

    <div class="nav-group">
        <p class="nav-label">Academic</p>
        <a href="#" class="nav-link"><i class="fas fa-book"></i> <span>Curriculum</span></a>
        <a href="#" class="nav-link"><i class="fas fa-calendar-alt"></i> <span>Schedules</span></a>
        <a href="#" class="nav-link"><i class="fas fa-chart-pie"></i> <span>Reports</span></a>
    </div>

    <div class="nav-group" style="margin-top: auto;">
        <a href="../../index.php" class="nav-link" style="color: #f87171;">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>
</aside>