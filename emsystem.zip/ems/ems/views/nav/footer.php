<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anahaway National High School | EMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../style/style.css">
</head>

<!-- =====================================================
     PREMIUM ATTRACTIVE FOOTER
===================================================== -->
<footer class="footer-section">
    <div class="container">

        <div class="row gy-5">

            <!-- School Info -->
            <div class="col-md-4">
                <h5 class="footer-brand">
                    Anahaway National High School
                </h5>
                <p class="footer-description">
                    Empowering students through academic excellence,
                    leadership, and innovation with our modern
                    Enrollment Management System.
                </p>
            </div>

            <!-- Quick Links -->
            <div class="col-md-2">
                <h6 class="footer-title">Quick Links</h6>
                <ul class="footer-links list-unstyled">
                    <li><a href="../home.php">Home</a></li>
                    <li><a href="../programs.php">Programs</a></li>
                    <li><a href="../admissions.php">Admissions</a></li>
                    <li><a href="../contact.php">Contact</a></li>
                </ul>
            </div>

            <!-- System -->
            <div class="col-md-3">
                <h6 class="footer-title">System Access</h6>
                <ul class="footer-links list-unstyled">
                    <li><a href="#">Student Portal</a></li>
                    <li><a href="#">Teacher Portal</a></li>
                    <li><a href="#">Admin Login</a></li>
                </ul>
            </div>

            <!-- Contact -->
            <div class="col-md-3">
                <h6 class="footer-title">Contact</h6>
                <p class="footer-contact">
                    <i class="fa-solid fa-location-dot me-2"></i>
                    Lopez Jaena, Misamis Occidental
                </p>
                <p class="footer-contact">
                    <i class="fa-solid fa-phone me-2"></i>
                    (000) 000-0000
                </p>
                <p class="footer-contact">
                    <i class="fa-solid fa-envelope me-2"></i>
                    info@anahawaynhs.edu.ph
                </p>
            </div>

        </div>

        <hr class="footer-divider">

        <!-- Bottom -->
        <div class="text-center footer-bottom">
            © <?php echo date('Y'); ?> Anahaway National High School |
            Enrollment Management System. All Rights Reserved.
        </div>

    </div>
</footer>