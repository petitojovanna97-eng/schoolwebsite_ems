<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMS | Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #1d4ed8;
            --primary-light: #e0e7ff;
            --dark: #0f172a;
            --bg: #f1f5f9;
            --card: #ffffff;
            --text: #1e293b;
            --muted: #64748b;
            --border: #e2e8f0;
            --success: #16a34a;
            --warning: #f59e0b;
            --danger: #dc2626;
            --transition: .3s;
        }

        * {
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--bg);
            color: var(--text);
        }

        /* Layout */
        .wrapper {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: var(--dark);
            color: #fff;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar h2 {
            font-size: 22px;
            margin-bottom: 30px;
            font-weight: 700;
            color: var(--primary);
            text-align: center;
        }

        .menu {
            flex: 1;
        }

        .menu-item {
            padding: 12px 15px;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 5px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: var(--transition);
        }

        .menu-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .menu-item.active {
            background: var(--primary);
        }

        .submenu {
            display: none;
            padding-left: 15px;
        }

        .submenu div {
            padding: 10px;
            font-size: 13px;
            color: #cbd5e1;
            cursor: pointer;
            border-radius: 6px;
            transition: var(--transition);
        }

        .submenu div:hover {
            background: var(--primary);
            color: #fff;
        }

        /* Logout button */
        .logout {
            margin-top: 20px;
            padding: 10px;
            background: var(--danger);
            text-align: center;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: var(--transition);
        }

        .logout:hover {
            opacity: 0.9;
        }

        /* Main content */
        .main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        /* Topbar */
        .topbar {
            background: var(--card);
            padding: 15px 25px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        }

        .search-box input {
            padding: 8px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            width: 250px;
            transition: var(--transition);
        }

        .search-box input:focus {
            border-color: var(--primary);
            outline: none;
        }

        .top-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .notification {
            position: relative;
            cursor: pointer;
            font-size: 18px;
        }

        .notification span {
            position: absolute;
            top: -6px;
            right: -8px;
            background: var(--danger);
            color: #fff;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 20px;
        }

        /* Profile */
        .profile {
            font-size: 14px;
            font-weight: 500;
        }

        /* Content */
        .content {
            padding: 30px;
        }

        .content h1 {
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: 700;
        }

        /* Cards */
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            background: var(--card);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            cursor: pointer;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card h3 {
            font-size: 14px;
            color: var(--muted);
            margin-bottom: 10px;
        }

        .card p {
            font-size: 24px;
            font-weight: 700;
        }

        .success {
            color: var(--success);
        }

        .warning {
            color: var(--warning);
        }

        .primary {
            color: var(--primary);
        }

        .danger {
            color: var(--danger);
        }

        /* Section */
        .section {
            margin-top: 40px;
        }

        .section h2 {
            font-size: 20px;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .activity {
            background: var(--card);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            font-size: 14px;
            border-left: 4px solid var(--primary);
            transition: var(--transition);
        }

        .activity:hover {
            background: var(--primary-light);
        }

        /* Table styles */
        .table-container {
            margin-top: 30px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: var(--card);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        table th,
        table td {
            padding: 12px 15px;
            text-align: left;
            font-size: 14px;
        }

        table th {
            background: var(--primary);
            color: #fff;
            font-weight: 500;
        }

        table tr:nth-child(even) {
            background: #f9fafb;
        }

        table tr:hover {
            background: var(--primary-light);
            color: #000;
        }

        /* Buttons */
        .btn {
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            background: var(--primary);
            color: #fff;
            transition: var(--transition);
        }

        .btn:hover {
            opacity: 0.9;
        }

        /* Responsive */
        @media(max-width:900px) {
            .wrapper {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                flex-direction: row;
                overflow-x: auto;
            }

            .main {
                flex: 1;
            }

            .cards {
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            }
        }
    </style>

    <style>
        /* Dropdown styles */
        .top-right .dropdown {
            display: none;
            position: absolute;
            right: 0;
            background: var(--card);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 220px;
            margin-top: 10px;
            z-index: 100;
            font-size: 13px;
        }

        .dropdown-item {
            padding: 10px 12px;
            cursor: pointer;
            transition: var(--transition);
        }

        .dropdown-item:hover {
            background: var(--primary-light);
        }

        .dropdown-footer {
            padding: 8px 12px;
            text-align: center;
            font-size: 12px;
            color: var(--primary);
            border-top: 1px solid var(--border);
            cursor: pointer;
            transition: var(--transition);
        }

        .dropdown-footer:hover {
            background: var(--primary-light);
        }

        /* Make notification and profile relative for dropdown positioning */
        .notification,
        .profile {
            position: relative;
        }
    </style>

    <!-- Student Attendance -->
    <style>
        :root {
            --primary: #1e3a8a;
            --primary-light: #3b82f6;
            --success: #16a34a;
            --danger: #dc2626;
            --warning: #d97706;
            --background: #f8fafc;
            --card: #ffffff;
            --text: #111827;
            --muted: #6b7280;
            --border: #e5e7eb;
            --radius: 8px;
        }

        /* Page */
        .content {
            padding: 40px;
            background: var(--background);
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
        }

        /* Card */
        .attendance-card {
            background: var(--card);
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.06);
        }

        /* Header */
        .card-header {
            border-bottom: 1px solid var(--border);
            padding-bottom: 20px;
            margin-bottom: 25px;
        }

        .card-header h1 {
            margin: 0;
            font-size: 24px;
        }

        .card-header p {
            margin-top: 5px;
            font-size: 14px;
            color: var(--muted);
        }

        /* Controls */
        .attendance-controls {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 20px;
            align-items: end;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .form-input {
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 14px;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-light);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }

        /* Quick Action Button */
        .btn-mark-all {
            background: var(--success);
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            font-size: 13px;
            cursor: pointer;
            height: 40px;
        }

        .btn-mark-all:hover {
            opacity: 0.9;
        }

        /* Table */
        .table-container {
            margin-top: 20px;
            overflow-x: auto;
        }

        .attendance-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        .attendance-table thead {
            background: var(--primary);
            color: white;
        }

        .attendance-table th {
            padding: 14px;
            text-align: left;
        }

        .attendance-table td {
            padding: 12px;
            border-bottom: 1px solid var(--border);
        }

        .attendance-table tbody tr:hover {
            background: #f1f5f9;
        }

        /* Status Colors */
        .present-label {
            color: var(--success);
            font-weight: 600;
        }

        .absent-label {
            color: var(--danger);
            font-weight: 600;
        }

        .late-label {
            color: var(--warning);
            font-weight: 600;
        }

        .center {
            text-align: center;
        }

        /* Radio Buttons */
        .attendance-table input[type="radio"] {
            transform: scale(1.1);
            cursor: pointer;
            accent-color: var(--primary);
        }

        /* Footer */
        .form-actions {
            margin-top: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .summary {
            font-size: 13px;
            color: var(--muted);
        }

        /* Buttons */
        .btn-primary {
            background: var(--primary);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-primary:hover {
            background: var(--primary-light);
        }

        .btn-secondary {
            background: #f3f4f6;
            border: 1px solid var(--border);
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
        }
    </style>
    <!-- End Attendance -->
</head>

<body>

    <div class="wrapper">

        <!-- Sidebar -->
        <div class="sidebar">
            <div>
                <h2>EMS System</h2>

                <div class="menu">
                    <div class="menu-item active" onclick="navigate('dashboard')">Dashboard</div>
                    <div class="menu-item" onclick="toggleMenu(this)">Student Management ▾</div>
                    <div class="submenu">
                        <div onclick="window.location.href='stud_management/add_student.php?page=add_student'">Add Student</div>
                        <div onclick="window.location.href='stud_management/stud_list.php?page=student_list'">Student List</div>
                        <div onclick="window.location.href='stud_management/attendance.php?page=attendance'">Attendance</div>
                    </div>

                    <div class="menu-item" onclick="toggleMenu(this)">Enrollment ▾</div>
                    <div class="submenu">
                        <div onclick="navigate('new-enrollment')">New Enrollment</div>
                        <div onclick="navigate('approval')">Approval</div>
                    </div>

                    <div class="menu-item" onclick="navigate('reports')">Reports</div>
                    <div class="menu-item" onclick="navigate('finance')">Finance / Billing</div>
                    <div class="menu-item" onclick="navigate('subjects')">Subjects & Curriculum</div>
                    <div class="menu-item" onclick="navigate('schedule')">Class Schedule</div>
                </div>
            </div>

            <div class="logout" onclick="confirmLogout()">Logout</div>
        </div>

        <!-- Main -->
        <div class="main">

            <!-- Topbar -->
            <div class="topbar">
                <div class="search-box">
                    <input type="text" placeholder="Search student, teacher, section..." id="search-input">
                </div>

                <div class="top-right">
                    <!-- Notification -->
                    <div class="notification" onclick="toggleDropdown('notif-dropdown')">
                        🔔<span>3</span>
                        <div class="dropdown" id="notif-dropdown">
                            <div class="dropdown-item">Juan Dela Cruz enrolled in Grade 10</div>
                            <div class="dropdown-item">Maria Santos promoted to Grade 11</div>
                            <div class="dropdown-item">Science 101 subject added</div>
                            <div class="dropdown-footer">See all notifications</div>
                        </div>
                    </div>

                    <!-- Profile -->
                    <div class="profile" onclick="toggleDropdown('profile-dropdown')">
                        Admin User ▾
                        <div class="dropdown" id="profile-dropdown">
                            <div class="dropdown-item" onclick="navigate('profile')">Profile</div>
                            <div class="dropdown-item" onclick="navigate('settings')">Settings</div>
                            <div class="dropdown-item" onclick="confirmLogout()">Logout</div>
                        </div>
                    </div>
                </div>

                <script>
                    // Toggle dropdowns
                    function toggleDropdown(id) {
                        const dropdown = document.getElementById(id);
                        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';

                        // Close other dropdowns
                        document.querySelectorAll('.top-right .dropdown').forEach(d => {
                            if (d.id !== id) d.style.display = 'none';
                        });
                    }

                    // Close dropdowns if clicking outside
                    window.onclick = function(e) {
                        if (!e.target.closest('.profile') && !e.target.closest('.notification')) {
                            document.querySelectorAll('.top-right .dropdown').forEach(d => d.style.display = 'none');
                        }
                    }

                    // Sample navigation function
                    function navigate(page) {
                        alert("Navigating to " + page);
                    }
                </script>
            </div>

            <!-- Content -->
            <div class="content">
                <h1>Student List</h1>

                <div class="cards">
                    <div class="card">
                        <h3>Total Students</h3>
                        <p class="primary">520</p>
                    </div>

                    <div class="card">
                        <h3>Total Enrolled</h3>
                        <p class="success">480</p>
                    </div>

                    <div class="card">
                        <h3>Pending Approval</h3>
                        <p class="warning">25</p>
                    </div>

                    <div class="card">
                        <h3>Available Slots</h3>
                        <p class="danger">40</p>
                    </div>
                </div>
                <!-- Student Attendance -->
                <div class="content">

                    <div class="attendance-card">

                        <div class="card-header">
                            <h1>Daily Attendance Sheet</h1>
                            <p>Select class section and record attendance for the chosen date.</p>
                        </div>

                        <form id="attendance-form" method="POST">

                            <!-- Controls -->
                            <div class="attendance-controls">

                                <div class="form-group">
                                    <label>Grade / Section *</label>
                                    <select name="section" required class="form-input">
                                        <option value="">Select Section</option>
                                        <option value="10A">Grade 10 - Section A</option>
                                        <option value="11B">Grade 11 - Section B</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Date *</label>
                                    <input type="date" name="attendance_date" required class="form-input">
                                </div>

                                <button type="button" class="btn-mark-all" onclick="markAllPresent()">
                                    Mark All Present
                                </button>

                            </div>

                            <!-- Attendance Table -->
                            <div class="table-container">
                                <table class="attendance-table">
                                    <thead>
                                        <tr>
                                            <th>Student ID</th>
                                            <th>Student Name</th>
                                            <th class="center present-label">Present</th>
                                            <th class="center absent-label">Absent</th>
                                            <th class="center late-label">Late</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <!-- Ready for PHP foreach loop -->
                                        <tr>
                                            <td>2026001</td>
                                            <td>Juan Dela Cruz</td>
                                            <td class="center">
                                                <input type="radio" name="attendance[2026001]" value="Present" required>
                                            </td>
                                            <td class="center">
                                                <input type="radio" name="attendance[2026001]" value="Absent">
                                            </td>
                                            <td class="center">
                                                <input type="radio" name="attendance[2026001]" value="Late">
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>2026002</td>
                                            <td>Maria Santos</td>
                                            <td class="center">
                                                <input type="radio" name="attendance[2026002]" value="Present" required>
                                            </td>
                                            <td class="center">
                                                <input type="radio" name="attendance[2026002]" value="Absent">
                                            </td>
                                            <td class="center">
                                                <input type="radio" name="attendance[2026002]" value="Late">
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>

                            <!-- Footer -->
                            <div class="form-actions">
                                <div class="summary">
                                    Attendance records will be saved permanently.
                                </div>

                                <div>
                                    <button type="reset" class="btn-secondary">Cancel</button>
                                    <button type="submit" class="btn-primary">Save Attendance</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>

                <script>
                    function markAllPresent() {
                        const radios = document.querySelectorAll('input[value="Present"]');
                        radios.forEach(radio => radio.checked = true);
                    }
                </script>

                <script>
                    function navigate(page) {
                        // Hide all student management pages
                        const pages = ['add-student-page', 'student-list-page', 'attendance-page'];
                        pages.forEach(p => document.getElementById(p).style.display = 'none');

                        if (page === 'add-student') document.getElementById('add-student-page').style.display = 'block';
                        if (page === 'student-list') document.getElementById('student-list-page').style.display = 'block';
                        if (page === 'attendance') document.getElementById('attendance-page').style.display = 'block';
                    }
                </script>
                <!-- End Studend Attendance -->

                <!-- Sidebar Dropdown Function -->
                <script>
                    function toggleMenu(element) {
                        let submenu = element.nextElementSibling;
                        submenu.style.display = submenu.style.display === "block" ? "none" : "block";
                    }

                    function navigate(page) {
                        alert("Navigating to " + page);
                    }

                    function confirmLogout() {
                        if (confirm("Are you sure you want to logout?")) {
                            window.location.href = "auth.php?logout=true";
                        }
                    }
                </script>
                <!-- End Sidebar Dropdown Function -->