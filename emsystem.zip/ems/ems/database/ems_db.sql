-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2026 at 02:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems_db`
--
CREATE DATABASE IF NOT EXISTS `ems_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ems_db`;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `parent_guardian_id` int(11) DEFAULT NULL,
  `address_type` enum('Home','Office','Other') DEFAULT NULL,
  `house_no` varchar(20) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `brgy` varchar(100) DEFAULT NULL,
  `municipality` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `addrs_date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `competencies`
--

CREATE TABLE `competencies` (
  `comp_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `comp_grade_id` int(11) DEFAULT NULL,
  `comp_suject` varchar(50) NOT NULL,
  `comp_desc` text DEFAULT NULL,
  `comp_code` varchar(50) DEFAULT NULL,
  `comp_type` enum('learned','least learned') DEFAULT NULL,
  `comp_quarter` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollment_info`
--

CREATE TABLE `enrollment_info` (
  `enrollment_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `school_year_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `school_year_to_enroll` varchar(20) DEFAULT NULL,
  `grade_level_to_enroll` varchar(20) DEFAULT NULL,
  `grade_level_completed` varchar(20) DEFAULT NULL,
  `name_of_the_adviser_last` varchar(100) DEFAULT NULL,
  `name_of_school_last_attended` varchar(100) DEFAULT NULL,
  `school_address_last` text DEFAULT NULL,
  `school_last_attended_id` varchar(50) DEFAULT NULL,
  `is_with_LMS` tinyint(1) DEFAULT NULL,
  `last_year_completed` varchar(20) DEFAULT NULL,
  `preferred_modality` varchar(50) DEFAULT NULL,
  `semester` varchar(20) DEFAULT NULL,
  `track` varchar(100) DEFAULT NULL,
  `strand` varchar(100) DEFAULT NULL,
  `credential_submitted` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grade_levels`
--

CREATE TABLE `grade_levels` (
  `grade_id` int(11) NOT NULL,
  `grade_level_number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parent_guardian`
--

CREATE TABLE `parent_guardian` (
  `parent_guardian_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `relationship` enum('Father','Mother','Guardian') DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `contact_no` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requirements`
--

CREATE TABLE `requirements` (
  `req_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `req_desc` text DEFAULT NULL,
  `req_status` varchar(50) DEFAULT NULL,
  `date_submitted` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `school_year`
--

CREATE TABLE `school_year` (
  `school_year_id` int(11) NOT NULL,
  `school_year` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL,
  `section_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `stud_id` int(11) NOT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `sy_section_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `parent_guardian_id` int(11) DEFAULT NULL,
  `stud_is_new_student` tinyint(1) DEFAULT NULL,
  `stud_LRN` varchar(20) DEFAULT NULL,
  `stud_last_name` varchar(50) DEFAULT NULL,
  `stud_first_name` varchar(50) DEFAULT NULL,
  `stud_middle_name` varchar(50) DEFAULT NULL,
  `stud_ext_name` varchar(10) DEFAULT NULL,
  `stud_sex` varchar(10) DEFAULT NULL,
  `stud_age` int(11) DEFAULT NULL,
  `stud_date_of_birth` date DEFAULT NULL,
  `stud_place_of_birth` varchar(100) DEFAULT NULL,
  `stud_religion` varchar(50) DEFAULT NULL,
  `stud_mother_tongue` varchar(50) DEFAULT NULL,
  `stud_nationality` varchar(50) DEFAULT NULL,
  `stud_indigenous_group` varchar(50) DEFAULT NULL,
  `stud_is_sned` tinyint(1) DEFAULT NULL,
  `stud_sned_manifestation` text DEFAULT NULL,
  `stud_has_pwd_id` varchar(50) DEFAULT NULL,
  `stud_emergency_cont_name` varchar(100) DEFAULT NULL,
  `stud_emergency_cont_no` varchar(20) DEFAULT NULL,
  `stud_4p_beneficiary` tinyint(1) DEFAULT NULL,
  `stud_4p_id_no` varchar(50) DEFAULT NULL,
  `stud_enrollment_status` varchar(50) DEFAULT NULL,
  `stud_date_of_enrollment` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sy_section`
--

CREATE TABLE `sy_section` (
  `sy_section_id` int(11) NOT NULL,
  `school_year_id` int(11) DEFAULT NULL,
  `sys_grade_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `comp_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `req_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `sy_section_id` int(11) DEFAULT NULL,
  `teacher_first_name` varchar(50) DEFAULT NULL,
  `teacher_last_name` varchar(50) DEFAULT NULL,
  `teacher_gender` varchar(10) DEFAULT NULL,
  `teacher_contact_no` varchar(20) DEFAULT NULL,
  `teacher_email` varchar(100) DEFAULT NULL,
  `teacher_specialization` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  `user_role` enum('Admin','Teacher','Staff') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `parent_guardian_id` (`parent_guardian_id`);

--
-- Indexes for table `competencies`
--
ALTER TABLE `competencies`
  ADD PRIMARY KEY (`comp_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `comp_grade_id` (`comp_grade_id`);

--
-- Indexes for table `enrollment_info`
--
ALTER TABLE `enrollment_info`
  ADD PRIMARY KEY (`enrollment_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `school_year_id` (`school_year_id`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `grade_levels`
--
ALTER TABLE `grade_levels`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `parent_guardian`
--
ALTER TABLE `parent_guardian`
  ADD PRIMARY KEY (`parent_guardian_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `address_id` (`address_id`);

--
-- Indexes for table `requirements`
--
ALTER TABLE `requirements`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `school_year`
--
ALTER TABLE `school_year`
  ADD PRIMARY KEY (`school_year_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`stud_id`),
  ADD UNIQUE KEY `stud_LRN` (`stud_LRN`),
  ADD KEY `grade_id` (`grade_id`),
  ADD KEY `sy_section_id` (`sy_section_id`),
  ADD KEY `address_id` (`address_id`),
  ADD KEY `parent_guardian_id` (`parent_guardian_id`);

--
-- Indexes for table `sy_section`
--
ALTER TABLE `sy_section`
  ADD PRIMARY KEY (`sy_section_id`),
  ADD KEY `school_year_id` (`school_year_id`),
  ADD KEY `section_id` (`section_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `sys_grade_id` (`sys_grade_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `competencies`
--
ALTER TABLE `competencies`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enrollment_info`
--
ALTER TABLE `enrollment_info`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grade_levels`
--
ALTER TABLE `grade_levels`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parent_guardian`
--
ALTER TABLE `parent_guardian`
  MODIFY `parent_guardian_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requirements`
--
ALTER TABLE `requirements`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `school_year`
--
ALTER TABLE `school_year`
  MODIFY `school_year_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sy_section`
--
ALTER TABLE `sy_section`
  MODIFY `sy_section_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`stud_id`);

--
-- Constraints for table `competencies`
--
ALTER TABLE `competencies`
  ADD CONSTRAINT `competencies_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`),
  ADD CONSTRAINT `competencies_ibfk_3` FOREIGN KEY (`comp_grade_id`) REFERENCES `grade_levels` (`grade_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `enrollment_info`
--
ALTER TABLE `enrollment_info`
  ADD CONSTRAINT `enrollment_info_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`stud_id`);

--
-- Constraints for table `parent_guardian`
--
ALTER TABLE `parent_guardian`
  ADD CONSTRAINT `parent_guardian_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`stud_id`),
  ADD CONSTRAINT `parent_guardian_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`);

--
-- Constraints for table `requirements`
--
ALTER TABLE `requirements`
  ADD CONSTRAINT `requirements_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`stud_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`sy_section_id`) REFERENCES `sy_section` (`sy_section_id`),
  ADD CONSTRAINT `students_ibfk_3` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`);

--
-- Constraints for table `sy_section`
--
ALTER TABLE `sy_section`
  ADD CONSTRAINT `sy_section_ibfk_1` FOREIGN KEY (`school_year_id`) REFERENCES `school_year` (`school_year_id`),
  ADD CONSTRAINT `sy_section_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `section` (`section_id`),
  ADD CONSTRAINT `sy_section_ibfk_3` FOREIGN KEY (`sys_grade_id`) REFERENCES `grade_levels` (`grade_id`),
  ADD CONSTRAINT `sy_section_ibfk_4` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
