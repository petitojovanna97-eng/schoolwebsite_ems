<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "ems_db";

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Set charset (recommended)
$conn->set_charset("utf8mb4");

// If everything is fine
// echo "Connected successfully";